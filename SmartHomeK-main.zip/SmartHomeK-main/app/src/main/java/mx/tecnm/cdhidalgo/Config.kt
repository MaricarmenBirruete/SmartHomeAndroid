package mx.tecnm.cdhidalgo

class Config {
    companion object {
        val URL: String = "http://172.18.0.2/"
    }
}