package mx.tecnm.cdhidalgo

interface MyListener {
    fun onClickEdit(posicion: Int)
    fun onClickDel(posicion: Int)
}